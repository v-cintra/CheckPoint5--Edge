"""
Exporta o histórico da adega (STH-Comet) para CSV e, opcionalmente, gera um gráfico.

Uso:
    python exportar_historico.py --host IP_DA_VM
    python exportar_historico.py --host IP_DA_VM --inicio 2026-10-01T00:00:00Z --grafico
"""

import argparse
import csv
from collections import defaultdict

import requests

ENTITY_TYPE = "IndoorEnvironmentObserved"
ENTITY_ID = "urn:ngsi-ld:IndoorEnvironmentObserved:adega001"
ATRIBUTOS = ("temperature", "relativeHumidity", "luminosity")
HEADERS = {"fiware-service": "smart", "fiware-servicepath": "/"}
LIMITE_POR_PAGINA = 100  # Máximo aceito pelo STH-Comet


def buscar_atributo(host: str, atributo: str, inicio: str | None, fim: str | None) -> list[dict]:
    """Busca todos os valores de um atributo, paginando de 100 em 100."""
    url = (f"http://{host}:8666/STH/v1/contextEntities/type/{ENTITY_TYPE}"
           f"/id/{ENTITY_ID}/attributes/{atributo}")
    valores, offset = [], 0

    while True:
        params = {"hLimit": LIMITE_POR_PAGINA, "hOffset": offset}
        if inicio:
            params["dateFrom"] = inicio
        if fim:
            params["dateTo"] = fim

        resposta = requests.get(url, headers=HEADERS, params=params, timeout=15)
        resposta.raise_for_status()

        pagina = resposta.json()["contextResponses"][0]["contextElement"]["attributes"][0]["values"]
        valores.extend(pagina)

        if len(pagina) < LIMITE_POR_PAGINA:
            return valores
        offset += LIMITE_POR_PAGINA


def montar_tabela(host: str, inicio: str | None, fim: str | None) -> list[dict]:
    """Agrupa os atributos por instante de recebimento (recvTime)."""
    linhas = defaultdict(dict)
    for atributo in ATRIBUTOS:
        for item in buscar_atributo(host, atributo, inicio, fim):
            linhas[item["recvTime"]][atributo] = float(item["attrValue"])

    return [
        {
            "recvTime": instante,
            "temperatura_c": dados.get("temperature"),
            "umidade_pct": round(dados["relativeHumidity"] * 100, 1) if "relativeHumidity" in dados else None,
            "luminosidade_pct": dados.get("luminosity"),
        }
        for instante, dados in sorted(linhas.items())
    ]


def salvar_csv(tabela: list[dict], caminho: str) -> None:
    with open(caminho, "w", newline="", encoding="utf-8") as arquivo:
        escritor = csv.DictWriter(arquivo, fieldnames=tabela[0].keys())
        escritor.writeheader()
        escritor.writerows(tabela)


def gerar_grafico(tabela: list[dict], caminho: str) -> None:
    import matplotlib.pyplot as plt

    instantes = [linha["recvTime"] for linha in tabela]
    fig, eixos = plt.subplots(3, 1, figsize=(11, 8), sharex=True)
    series = (
        ("temperatura_c", "Temperatura (°C)", (10, 16)),
        ("umidade_pct", "Umidade (%)", (60, 80)),
        ("luminosidade_pct", "Luminosidade (%)", None),
    )

    for eixo, (chave, titulo, faixa_ideal) in zip(eixos, series):
        eixo.plot(instantes, [linha[chave] for linha in tabela])
        eixo.set_ylabel(titulo)
        if faixa_ideal:
            eixo.axhspan(*faixa_ideal, alpha=0.15, color="green", label="Faixa ideal")
            eixo.legend(loc="upper right")

    eixos[-1].set_xticks(instantes[:: max(1, len(instantes) // 8)])
    fig.autofmt_xdate()
    fig.suptitle("Vinheria Agnello - Condições da adega")
    fig.tight_layout()
    fig.savefig(caminho, dpi=150)


def main() -> None:
    parser = argparse.ArgumentParser(description="Exporta o histórico da adega do STH-Comet.")
    parser.add_argument("--host", required=True, help="IP da VM com o FIWARE")
    parser.add_argument("--inicio", help="Data inicial ISO 8601 (ex: 2026-10-01T00:00:00Z)")
    parser.add_argument("--fim", help="Data final ISO 8601")
    parser.add_argument("--saida", default="historico_adega.csv", help="Arquivo CSV de saída")
    parser.add_argument("--grafico", action="store_true", help="Gera historico_adega.png")
    args = parser.parse_args()

    tabela = montar_tabela(args.host, args.inicio, args.fim)
    if not tabela:
        print("Nenhum dado encontrado. Verifique se a subscription do STH-Comet foi criada.")
        return

    salvar_csv(tabela, args.saida)
    print(f"{len(tabela)} registros exportados para {args.saida}")

    if args.grafico:
        gerar_grafico(tabela, "historico_adega.png")
        print("Gráfico salvo em historico_adega.png")


if __name__ == "__main__":
    main()
