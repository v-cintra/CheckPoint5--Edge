/*
 * Vinheria Agnello - Monitoramento da Adega (Fase 2 - IoT)
 * ESP32 + DHT11 (temperatura/umidade) + LDR (luminosidade)
 * Envio via MQTT (UltraLight 2.0) para o IoT Agent do FIWARE.
 *
 * Bibliotecas necessárias (Arduino IDE > Gerenciador de Bibliotecas):
 *  - PubSubClient (Nick O'Leary)
 *  - DHT sensor library (Adafruit) + Adafruit Unified Sensor
 */

#include <WiFi.h>
#include <PubSubClient.h>
#include <DHT.h>
#include <time.h>
#include "soc/soc.h"
#include "soc/rtc_cntl_reg.h"

// ================== CONFIGURAÇÕES (ALTERE AQUI) ==================
const char* WIFI_SSID     = "FIAP-IOT";
const char* WIFI_PASSWORD = "F!@p25.IOT";

const char* MQTT_BROKER    = "3.135.234.101";   // IP onde o FIWARE está rodando
const uint16_t MQTT_PORT   = 1883;
const char* MQTT_CLIENT_ID = "fiware_adega001";    // Deve ser único no broker

// Tópicos no padrão do IoT Agent UltraLight: /<apikey>/<device_id>/...
const char* TOPICO_ATTRS  = "/TEF/adega001/attrs";   // Publica medições
const char* TOPICO_CMD    = "/TEF/adega001/cmd";     // Recebe comandos
const char* TOPICO_CMDEXE = "/TEF/adega001/cmdexe";  // Confirma comandos
const char* DEVICE_ID     = "adega001";

// Servidores NTP (o ESP32 tenta os três)
const char* NTP_SERVER_1 = "a.st1.ntp.br";
const char* NTP_SERVER_2 = "time.google.com";
const char* NTP_SERVER_3 = "pool.ntp.org";
constexpr unsigned long TIMEOUT_NTP_MS = 15000;  // Não trava o boot se a rede bloquear NTP

// ================== HARDWARE (conforme montagem do slide 10) ==================
constexpr uint8_t PINO_DHT = 4;    // D4  -> DATA do DHT11
constexpr uint8_t PINO_LDR = 34;   // D34 -> LDR (entrada analógica)
constexpr uint8_t PINO_LED = 2;    // D2  -> LED1 da placa
#define TIPO_DHT DHT11

// Se a luminosidade aparecer invertida (escuro = 100%), troque para true
constexpr bool LDR_INVERTIDO = false;

constexpr unsigned long INTERVALO_LEITURA_MS = 10000;  // 10 s (DHT11 exige >= 1 s)

// ================== OBJETOS GLOBAIS ==================
WiFiClient espClient;
PubSubClient mqtt(espClient);
DHT dht(PINO_DHT, TIPO_DHT);

unsigned long ultimaLeitura = 0;

// ================== CONECTIVIDADE ==================
void conectarWiFi() {
  if (WiFi.status() == WL_CONNECTED) return;

  Serial.printf("[WiFi] Conectando a %s", WIFI_SSID);
  WiFi.mode(WIFI_STA);
  WiFi.setTxPower(WIFI_POWER_8_5dBm);  // Menor pico de consumo na transmissão
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.printf("\n[WiFi] Conectado! IP: %s\n", WiFi.localIP().toString().c_str());
}

bool relogioSincronizado() {
  return time(nullptr) > 1700000000;  // Qualquer data após 2023 indica horário válido
}

void sincronizarRelogio() {
  // UTC: timestamp enviado em ISO 8601 com "Z".
  // Se não sincronizar agora, o SNTP continua tentando em segundo plano.
  configTime(0, 0, NTP_SERVER_1, NTP_SERVER_2, NTP_SERVER_3);
  Serial.print("[NTP] Sincronizando horário");

  const unsigned long inicio = millis();
  while (!relogioSincronizado() && millis() - inicio < TIMEOUT_NTP_MS) {
    delay(500);
    Serial.print(".");
  }

  if (relogioSincronizado()) {
    Serial.println("\n[NTP] Horário sincronizado.");
  } else {
    Serial.println("\n[NTP] Sem resposta. Seguindo sem dateObserved (TimeInstant do IoT Agent registra o horário).");
  }
}

void conectarMQTT() {
  while (!mqtt.connected()) {
    Serial.printf("[MQTT] Conectando ao broker %s:%u... ", MQTT_BROKER, MQTT_PORT);

    if (mqtt.connect(MQTT_CLIENT_ID)) {
      Serial.println("conectado!");
      mqtt.subscribe(TOPICO_CMD);
      Serial.printf("[MQTT] Inscrito em %s\n", TOPICO_CMD);
    } else {
      Serial.printf("falhou (rc=%d). Nova tentativa em 2 s\n", mqtt.state());
      delay(2000);
    }
  }
}

// ================== UTILITÁRIOS ==================
String obterTimestampISO() {
  time_t agora = time(nullptr);
  struct tm utc;
  gmtime_r(&agora, &utc);

  char buffer[25];
  strftime(buffer, sizeof(buffer), "%Y-%m-%dT%H:%M:%SZ", &utc);
  return String(buffer);
}

float lerLuminosidadePercentual() {
  const int leitura = analogRead(PINO_LDR);  // 0 a 4095 (ADC 12 bits)
  const float percentual = (leitura / 4095.0f) * 100.0f;
  return LDR_INVERTIDO ? 100.0f - percentual : percentual;
}

// ================== ATUADOR (LED) ==================
void definirLed(bool ligado) {
  digitalWrite(PINO_LED, ligado ? HIGH : LOW);
  mqtt.publish(TOPICO_ATTRS, ligado ? "s|on" : "s|off");
}

void callbackMQTT(char* topico, byte* payload, unsigned int tamanho) {
  String mensagem;
  mensagem.reserve(tamanho);
  for (unsigned int i = 0; i < tamanho; i++) mensagem += (char)payload[i];

  Serial.printf("[MQTT] Mensagem em %s: %s\n", topico, mensagem.c_str());

  // Formato UltraLight do comando: "<device_id>@<comando>|<valor>"
  const String prefixo = String(DEVICE_ID) + "@";
  if (!mensagem.startsWith(prefixo)) return;

  const int fimComando = mensagem.indexOf('|');
  const String comando = (fimComando == -1)
      ? mensagem.substring(prefixo.length())
      : mensagem.substring(prefixo.length(), fimComando);

  if (comando == "on" || comando == "off") {
    definirLed(comando == "on");
    // Confirmação para o IoT Agent marcar o comando como OK (senão fica PENDING)
    const String resposta = prefixo + comando + "|" + comando;
    mqtt.publish(TOPICO_CMDEXE, resposta.c_str());
  }
}

// ================== SENSORES ==================
void publicarLeituras() {
  const float temperatura  = dht.readTemperature();
  const float umidade      = dht.readHumidity();
  const float luminosidade = lerLuminosidadePercentual();

  if (isnan(temperatura) || isnan(umidade)) {
    Serial.println("[DHT11] Falha na leitura. Verifique a ligação.");
    return;
  }

  // Smart Data Model: relativeHumidity é uma fração entre 0 e 1
  char payload[128];
  if (relogioSincronizado()) {
    snprintf(payload, sizeof(payload), "t|%.1f|h|%.2f|l|%.1f|d|%s",
             temperatura, umidade / 100.0f, luminosidade, obterTimestampISO().c_str());
  } else {
    snprintf(payload, sizeof(payload), "t|%.1f|h|%.2f|l|%.1f",
             temperatura, umidade / 100.0f, luminosidade);
  }

  mqtt.publish(TOPICO_ATTRS, payload);
  Serial.printf("[PUB] %s -> %s\n", TOPICO_ATTRS, payload);
}

// ================== CICLO PRINCIPAL ==================
void setup() {
  WRITE_PERI_REG(RTC_CNTL_BROWN_OUT_REG, 0);  // Evita reset por queda de tensão no pico do Wi-Fi
  Serial.begin(115200);
  pinMode(PINO_LED, OUTPUT);
  digitalWrite(PINO_LED, LOW);
  analogReadResolution(12);

  dht.begin();
  conectarWiFi();
  sincronizarRelogio();

  mqtt.setServer(MQTT_BROKER, MQTT_PORT);
  mqtt.setCallback(callbackMQTT);
  conectarMQTT();

  definirLed(false);  // Publica o estado inicial
}

void loop() {
  conectarWiFi();
  if (!mqtt.connected()) conectarMQTT();
  mqtt.loop();

  if (millis() - ultimaLeitura >= INTERVALO_LEITURA_MS) {
    ultimaLeitura = millis();
    publicarLeituras();
  }
}
