# 🍷 Vinheria Agnello — Monitoramento IoT da Adega (Fase 2)

Checkpoint 05 — **Edge Computing & Computer Systems** — Engenharia de Software FIAP (turma 1ESR)
Prof. Lucas Demetrius Augusto

## 👥 Integrantes
 Octavio Kal Oliveira Lima - RM571838

Vitor Santos Cintra rm569416

Guilherme Zeferino Gonçalves Rm - 572075

Douglas Ferreira Santos Patriota 
Rm: 569713
 Pedro Henrique santos de brito Rm573187
 Caique Kenji rm570368
---

## 📌 Sobre o projeto

Na fase 1, o sistema da Vinheria Agnello apenas avisava, por LEDs, quando o ambiente estava claro demais. Os proprietários pediram:

- valores **exatos** de temperatura e umidade do depósito;
- **histórico** dos últimos dias e meses;
- **exportação** dos dados para gráficos, análises e relatórios (rastreabilidade);
- **integração com distribuidoras europeias**.

Esta fase 2 resolve isso com um **ESP32** lendo um **DHT11** (temperatura/umidade) e um **LDR** (luminosidade), enviando os dados via **Wi-Fi + MQTT** para o back-end **FIWARE**, que expõe tudo pela interface padrão **NGSIv2** e guarda o histórico no **STH-Comet**. A entidade segue o **Smart Data Model** europeu `IndoorEnvironmentObserved`, garantindo interoperabilidade com o ecossistema da União Europeia.

### ✅ Requisitos atendidos

| Requisito | Como foi atendido |
|-----------|-------------------|
| Envio dos dados ao FIWARE via MQTT | ESP32 publica em `/TEF/adega001/attrs` no Mosquitto; o IoT Agent UltraLight converte para NGSI |
| Timestamp de cada leitura | `TimeInstant` gerado automaticamente pelo IoT Agent em toda medição + `dateObserved` (ISO 8601, via NTP no ESP32, enviado quando a rede permite NTP) |
| Comunicação Wi-Fi do MCU | Biblioteca `WiFi.h` do ESP32 |
| Interface em conformidade com NGSI | Orion Context Broker (NGSIv2) na porta 1026 |
| Smart Data Models | Entidade do tipo `IndoorEnvironmentObserved` (`temperature`, `relativeHumidity`, `dateObserved`) |
| Armazenamento histórico | STH-Comet + MongoDB, consultas por período e agregações |
| Exportação para relatórios | Script `scripts/exportar_historico.py` gera CSV e gráfico |
| Leitura e escrita pelo MyMQTT | Leitura em `/TEF/adega001/attrs`, escrita de comandos em `/TEF/adega001/cmd` |

---

## 🏗️ Arquitetura

```
 ┌──────────────────────┐   Wi-Fi / MQTT    ┌──────────────┐
 │ ESP32 + DHT11 + LDR  │ ────────────────► │  Mosquitto   │ :1883
 │  (LED como atuador)  │ ◄──── comandos ── │ (MQTT Broker)│ ◄──── MyMQTT (app)
 └──────────────────────┘                   └──────┬───────┘
                                                   │ MQTT
                                            ┌──────▼───────┐      ┌────────────────┐
                                            │  IoT Agent   │ ───► │ MongoDB        │
                                            │ UltraLight   │ :4041│ (interno)      │
                                            └──────┬───────┘      └────────────────┘
                                                   │ NGSIv2
                                            ┌──────▼───────┐      ┌────────────────┐
 Postman / Apps / Distribuidoras ◄─NGSIv2─► │ Orion Context│ ───► │ STH-Comet :8666│
                                            │ Broker :1026 │ notif│ + MongoDB      │
                                            └──────────────┘      │ (histórico)    │
                                                                  └───────┬────────┘
                                                                          │ REST
                                                          exportar_historico.py → CSV / gráfico
```

| Componente | Porta | Função |
|------------|-------|--------|
| Mosquitto | 1883 | Broker MQTT |
| IoT Agent UL | 4041 | Traduz MQTT/UltraLight ↔ NGSIv2 e provisiona dispositivos |
| Orion | 1026 | Context Broker — estado atual das entidades (NGSIv2) |
| STH-Comet | 8666 | Séries históricas (Short Time Historic) |
| MongoDB histórico | 27017 | Base do STH-Comet |

---

## 📁 Estrutura do repositório

```
vinheria-agnello-iot/
├── README.md
├── firmware/
│   └── vinheria_agnello/
│       └── vinheria_agnello.ino      # Código do ESP32
├── fiware/
│   └── docker-compose.yml            # Back-end FIWARE completo
├── postman/
│   └── VinheriaAgnello.postman_collection.json
└── scripts/
    ├── exportar_historico.py         # Exporta histórico para CSV/PNG
    └── requirements.txt
```

---

## 🔌 Hardware e montagem

**Componentes:** ESP32 DevKit (ESP-WROOM-32), sensor DHT11, LDR (com divisor resistivo da placa didática), LED, jumpers.

| Pino ESP32 | Ligação na placa | Função |
|------------|------------------|--------|
| 3V3 | VCC | Alimentação |
| GND | GND | Terra |
| D4 (GPIO 4) | DATA (DHT11) | Temperatura e umidade |
| D34 (GPIO 34) | LDR | Luminosidade (entrada analógica) |
| D2 (GPIO 2) | LED1 | Atuador controlado por comando |

> O GPIO 34 é apenas de entrada e pertence ao ADC1, que funciona normalmente com o Wi-Fi ligado (o ADC2 não funciona com Wi-Fi ativo).

---

## 🚀 Passo a passo para replicar

### 1. Preparar a máquina virtual

Use uma VM Linux (Azure, AWS ou similar) com IP público e **Docker + Docker Compose** instalados. Libere no firewall/NSG as portas **TCP de entrada**: `1026`, `1883`, `4041` e `8666`.

```bash
# Ubuntu: instalação rápida do Docker
curl -fsSL https://get.docker.com | sudo sh
sudo usermod -aG docker $USER   # faça logout/login depois
```

### 2. Subir o back-end FIWARE

```bash
git clone <URL_DESTE_REPOSITORIO>
cd vinheria-agnello-iot/fiware
docker compose up -d
docker compose ps        # todos os containers devem estar "running"
```

Teste rápido:

```bash
curl http://localhost:4041/iot/about
curl http://localhost:1026/version
curl http://localhost:8666/version
```

### 3. Provisionar o dispositivo (Postman)

1. Importe `postman/VinheriaAgnello.postman_collection.json` no Postman.
2. Na aba **Variables** da collection, troque `url` pelo IP público da VM.
3. Execute, na ordem, a pasta **2. Provisionamento**:
   1. **Criar Service Group** — registra a apikey `TEF`.
   2. **Provisionar dispositivo adega001** — cria o dispositivo e mapeia os atributos.
   3. **Criar subscription STH-Comet** — faz o Orion enviar cada atualização para o histórico.

Todas as requisições usam os headers `fiware-service: smart` e `fiware-servicepath: /`.

<details>
<summary>Alternativa via cURL</summary>

```bash
IP=SEU_IP

curl -X POST "http://$IP:4041/iot/services" \
  -H "Content-Type: application/json" -H "fiware-service: smart" -H "fiware-servicepath: /" \
  -d '{"services":[{"apikey":"TEF","cbroker":"http://orion:1026","entity_type":"IndoorEnvironmentObserved","resource":"/iot/d"}]}'

curl -X POST "http://$IP:4041/iot/devices" \
  -H "Content-Type: application/json" -H "fiware-service: smart" -H "fiware-servicepath: /" \
  -d '{"devices":[{"device_id":"adega001","entity_name":"urn:ngsi-ld:IndoorEnvironmentObserved:adega001","entity_type":"IndoorEnvironmentObserved","protocol":"PDI-IoTA-UltraLight","transport":"MQTT","timestamp":true,
  "attributes":[{"object_id":"t","name":"temperature","type":"Number"},{"object_id":"h","name":"relativeHumidity","type":"Number"},{"object_id":"l","name":"luminosity","type":"Number"},{"object_id":"d","name":"dateObserved","type":"DateTime"},{"object_id":"s","name":"state","type":"Text"}],
  "commands":[{"name":"on","type":"command"},{"name":"off","type":"command"}],
  "static_attributes":[{"name":"name","type":"Text","value":"Adega - Vinheria Agnello"}]}]}'

curl -X POST "http://$IP:1026/v2/subscriptions" \
  -H "Content-Type: application/json" -H "fiware-service: smart" -H "fiware-servicepath: /" \
  -d '{"description":"Historico adega","subject":{"entities":[{"id":"urn:ngsi-ld:IndoorEnvironmentObserved:adega001","type":"IndoorEnvironmentObserved"}]},
  "notification":{"http":{"url":"http://sth-comet:8666/notify"},"attrs":["temperature","relativeHumidity","luminosity","dateObserved","state"],"attrsFormat":"legacy"}}'
```
</details>

### 4. Gravar o firmware no ESP32

1. Instale a **Arduino IDE** e adicione o suporte ao ESP32 (Gerenciador de Placas → *esp32 by Espressif Systems*).
2. Instale as bibliotecas: **PubSubClient** (Nick O'Leary), **DHT sensor library** (Adafruit) e **Adafruit Unified Sensor**.
3. Abra `firmware/vinheria_agnello/vinheria_agnello.ino` e edite:
   ```cpp
   const char* WIFI_SSID     = "SEU_WIFI";
   const char* WIFI_PASSWORD = "SUA_SENHA";
   const char* MQTT_BROKER   = "IP_PUBLICO_DA_VM";
   ```
4. Placa: **ESP32 Dev Module** → selecione a porta → **Upload**.
5. Abra o **Monitor Serial (115200 baud)**. Saída esperada:
   ```
   [WiFi] Conectado! IP: 192.168.0.15
   [NTP] Horário sincronizado.
   [MQTT] Conectando ao broker x.x.x.x:1883... conectado!
   [PUB] /TEF/adega001/attrs -> t|22.0|h|0.61|l|34.5|d|2026-10-22T19:30:10Z
   ```

> Se a luminosidade ficar invertida (ambiente escuro mostrando valor alto), altere `LDR_INVERTIDO` para `true`.

### 5. Leitura e escrita com o MyMQTT

1. Instale o **MyMQTT** (Android/iOS) e configure: *Broker* = IP da VM, *Port* = `1883`, sem usuário/senha. Use um *Client ID* diferente de `fiware_adega001`, que é o do ESP32.
2. **Leitura** — em *Subscribe*, inscreva-se em `/TEF/adega001/attrs`. As medições chegam a cada 10 s:
   ```
   t|22.0|h|0.61|l|34.5|d|2026-10-22T19:30:10Z
   ```
3. **Escrita** — em *Publish*, envie para o tópico `/TEF/adega001/cmd`:

   | Payload | Efeito |
   |---------|--------|
   | `adega001@on\|` | Liga o LED (D2) |
   | `adega001@off\|` | Desliga o LED |

   O ESP32 responde publicando `s|on` / `s|off` em `/TEF/adega001/attrs`, visível no próprio MyMQTT.

> Os comandos também podem ser enviados pelo Orion (pasta **4. Comandos** do Postman); o IoT Agent repassa ao ESP32 pelo MQTT.

### 6. Consultar o estado atual (NGSIv2)

```bash
curl "http://$IP:1026/v2/entities/urn:ngsi-ld:IndoorEnvironmentObserved:adega001?options=keyValues" \
  -H "fiware-service: smart" -H "fiware-servicepath: /"
```

Resposta esperada:

```json
{
  "id": "urn:ngsi-ld:IndoorEnvironmentObserved:adega001",
  "type": "IndoorEnvironmentObserved",
  "temperature": 22.0,
  "relativeHumidity": 0.61,
  "luminosity": 34.5,
  "dateObserved": "2026-10-22T19:30:10.000Z",
  "state": "off",
  "name": "Adega - Vinheria Agnello",
  "TimeInstant": "2026-10-22T19:30:10.512Z"
}
```

### 7. Consultar o histórico (STH-Comet)

```bash
# Últimas 30 leituras de temperatura
curl "http://$IP:8666/STH/v1/contextEntities/type/IndoorEnvironmentObserved/id/urn:ngsi-ld:IndoorEnvironmentObserved:adega001/attributes/temperature?lastN=30" \
  -H "fiware-service: smart" -H "fiware-servicepath: /"

# Por período (paginado de 100 em 100)
.../attributes/temperature?hLimit=100&hOffset=0&dateFrom=2026-10-01T00:00:00Z&dateTo=2026-10-31T23:59:59Z

# Agregado por hora (média = sum / samples)
.../attributes/temperature?aggrMethod=sum&aggrPeriod=hour&dateFrom=2026-10-22T00:00:00Z
```

### 8. Exportar para relatórios

```bash
cd scripts
pip install -r requirements.txt
python exportar_historico.py --host SEU_IP --grafico
# Opcional: --inicio 2026-10-01T00:00:00Z --fim 2026-10-31T23:59:59Z --saida outubro.csv
```

Gera `historico_adega.csv` (pronto para Excel/Power BI) e `historico_adega.png` com as faixas ideais destacadas.

---

## 🧾 Modelo de dados (Smart Data Model)

Entidade baseada em [`IndoorEnvironmentObserved`](https://github.com/smart-data-models/dataModel.Environment/tree/master/IndoorEnvironmentObserved):

| Atributo | Tipo | Objeto UL | Descrição |
|----------|------|-----------|-----------|
| `temperature` | Number | `t` | Temperatura em °C (padrão SDM) |
| `relativeHumidity` | Number | `h` | Umidade relativa como fração de 0 a 1 (padrão SDM; 0.61 = 61%) |
| `dateObserved` | DateTime | `d` | Momento da leitura no ESP32 (ISO 8601, UTC); enviado quando o NTP sincroniza |
| `luminosity` | Number | `l` | Luminosidade relativa em % (atributo próprio: o LDR não é calibrado em lux, por isso não usamos `illuminance`) |
| `state` | Text | `s` | Estado do LED (on/off) |
| `on` / `off` | command | — | Comandos do atuador |
| `TimeInstant` | DateTime | — | Gerado automaticamente pelo IoT Agent ao receber a medição |

### Faixas ideais de armazenamento

| Fator | Ideal | Observação |
|-------|-------|-----------|
| Temperatura | ~13 °C (10–16 °C) | Variações acima de 3 °C geram aromas indesejados |
| Umidade | ~70% (60–80%) | Seca resseca a rolha; excesso gera fungos e danifica rótulos |
| Luminosidade | Penumbra (valor baixo) | UV altera compostos orgânicos, principalmente em brancos e espumantes |

---

## 🛠️ Solução de problemas

| Problema | Causa provável / solução |
|----------|--------------------------|
| `[MQTT] falhou (rc=-2)` | Porta 1883 bloqueada no firewall da VM ou IP incorreto |
| `[NTP] Sem resposta` | A rede bloqueia NTP (UDP 123). O firmware segue sem `dateObserved` e o `TimeInstant` do IoT Agent registra o horário |
| ESP32 reinicia sozinho (`ets Jul 29 2019...` no Serial) | Queda de tensão no pico do Wi-Fi. O firmware já desativa o brownout e reduz a potência de TX; se persistir, troque a porta/cabo USB |
| ESP32 desconecta quando o MyMQTT conecta | O celular está usando o mesmo Client ID do ESP32 (`fiware_adega001`); use um ID diferente |
| Leituras `NaN` no DHT11 | Ligação do DATA no D4, alimentação 3V3/GND ou intervalo de leitura muito curto |
| Entidade não aparece no Orion | Service group ou dispositivo não provisionado; confira os headers `fiware-service` |
| Histórico vazio | Subscription do STH-Comet não criada ou criada com headers diferentes |
| Comando fica `PENDING` | ESP32 desconectado ou sem inscrição em `/TEF/adega001/cmd` |
| Horário errado no `dateObserved` | O valor está em UTC (horário de Brasília = UTC−3), comportamento esperado |

---

## 📚 Referências

- FIWARE Orion Context Broker — https://fiware-orion.readthedocs.io
- FIWARE IoT Agent UltraLight — https://fiware-iotagent-ul.readthedocs.io
- FIWARE STH-Comet — https://fiware-sth-comet.readthedocs.io
- Smart Data Models — https://smartdatamodels.org
